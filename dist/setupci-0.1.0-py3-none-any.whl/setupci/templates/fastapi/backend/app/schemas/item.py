from typing import Optional
from pydantic import BaseModel

# Shared properties
class ItemBase(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    is_done: Optional[bool] = False

# Properties to receive on item creation
class ItemCreate(ItemBase):
    title: str

# Properties to receive on item update
class ItemUpdate(ItemBase):
    pass

# Properties stored in DB
class ItemInDBBase(ItemBase):
    id: int
    title: str

    class Config:
        from_attributes = True

# Properties to return to client
class Item(ItemInDBBase):
    pass
