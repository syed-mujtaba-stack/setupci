from sqlalchemy import Column, Integer, String, Boolean
from app.db.session import Base

class Item(Base):
    __tablename__ = "items"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True, nullable=False)
    description = Column(String, index=True)
    is_done = Column(Boolean, default=False)
