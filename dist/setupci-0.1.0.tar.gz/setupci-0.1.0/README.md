# setupci

`setupci` is an interactive Python CLI tool to bootstrap project structures for various Python frameworks (FastAPI, Flask, Django, and General Python). It helps you initialize standard simple scripts or highly structured, professional backend projects in seconds.

## Installation

Install directly from PyPI (once published) or run locally in development:

```bash
pip install setupci
```

## Usage

Navigate to your desired project directory and run:

```bash
setupci init .
```

You will be prompted with:
1. **Framework Selection**: Choose between FastAPI, Flask, Django, or General Python.
2. **Project Type**: Choose between:
   - **Backend**: A professional project layout with clean architecture (Dockerfiles, config files, environment templates, modular routes/apps).
   - **Simple**: A basic starting point with single-file endpoints, requirements, and minimum configuration.

## Features

- **FastAPI**: Professional multi-module folder structure with standard configuration, api routes, database hooks, schemas, and a Dockerfile.
- **Flask**: Application factory pattern setup with configuration separation andblueprint configurations.
- **Django**: Configured using environment variables (`django-environ`), custom directory patterns (apps inside `apps/` or root settings), and a clean structure.
- **General**: standard library package template with `src/` layout or simple scripts.
- Modern packaging using `pyproject.toml`.
